

import add from './add';

const result1= add(2,3);

console.assert(result1 === 5, 'Test Case 1 Failed');

const result2 =add(5,-2);

console.log(result2 === 3, 'Test Case 2 Failed');

console.log("All Test Case Passed")