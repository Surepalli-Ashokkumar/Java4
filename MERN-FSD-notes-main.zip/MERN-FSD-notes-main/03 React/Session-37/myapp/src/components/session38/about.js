
import React from "react";
function About(){

    return(<div>
        <h1>About Us</h1>
        <p>Paragraph1</p>
        <p>Paragraph2</p>
    </div>)
}

export default About