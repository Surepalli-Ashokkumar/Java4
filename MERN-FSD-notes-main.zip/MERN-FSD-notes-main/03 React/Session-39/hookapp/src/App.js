import logo from './logo.svg';
import './App.css';
import HookDemo from './hoodemo';
 

function App() {
  return (
    
    <div>
      <HookDemo/>
    </div>
  );
}

export default App;
