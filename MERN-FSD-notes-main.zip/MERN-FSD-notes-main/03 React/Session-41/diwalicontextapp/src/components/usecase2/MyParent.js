

import MyChild from "./MyChild"

function MyParent(){
    return (
        <div>
            <h2>Parent</h2>
           <MyChild/>
        </div>
    )
}

export default MyParent;