import { ProductList } from "./session2/productlist";
import ReactBootstrap from "./session2/reactbootstrap";
import ReactBootstrap2 from "./session2/reactbootstrap2";

function Session2(){

    //const mymsg=props.message;

    return(<div>
        <ReactBootstrap/>
        <ReactBootstrap2/>
        <ProductList/>
    </div>);
}

export default Session2;