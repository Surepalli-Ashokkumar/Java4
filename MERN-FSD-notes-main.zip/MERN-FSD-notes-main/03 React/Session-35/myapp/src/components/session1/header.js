//Header Component

export function Header(){
    return(
        <div className="App">
            <div className="text-info">
                <div className="bg-success">
                    <h1>Web Page</h1>
                </div>
                
            </div>

        </div>
        
    )
}