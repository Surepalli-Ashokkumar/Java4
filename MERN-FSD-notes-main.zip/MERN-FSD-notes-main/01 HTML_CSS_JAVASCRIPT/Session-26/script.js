function test(){
    alert("Hello");
}

function test1(){
    alert("Hello World 1");
}

function test2(){
    alert("Hello World 2");
}

test();
test1();
test2();