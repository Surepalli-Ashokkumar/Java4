//external javascript
alert("This is From External Javascript");