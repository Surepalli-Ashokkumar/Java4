console.log("This is Step-1");

setTimeout(function(){
    console.log("This is Step-2");
},200);

console.log("This is step-3");




