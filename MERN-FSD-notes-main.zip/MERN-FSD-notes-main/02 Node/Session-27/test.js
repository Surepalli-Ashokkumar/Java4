console.log("Custom File");

function hello(){
    console.log("Hello World");
}

hello();

const array=[1,2,3,4,5];

array.forEach((value)=>{
    console.log(value);
})